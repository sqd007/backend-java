package com.matchwork.services;

import java.util.List;

import com.matchwork.model.Candidato;

public interface CandidatoService {
	
	List<Candidato> getAllCandidatos();
	
	Candidato getCandidatoById(Long id);
	
	Candidato saveCandidato(Candidato candidato);
	
	Candidato updateCandidato(Long id, Candidato candidatoAtualizado);
	
	void deleteCandidato(Long id);
	
}
