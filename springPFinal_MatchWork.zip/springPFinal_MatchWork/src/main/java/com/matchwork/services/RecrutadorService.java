package com.matchwork.services;

import java.util.List;

import com.matchwork.model.Recrutador;

public interface RecrutadorService {

	List<Recrutador> getAllRecrutadores();

	Recrutador getRecrutadorById(Long id);

	Recrutador saveRecrutador(Recrutador recrutador);

	Recrutador updateRecrutador(Long id, Recrutador recrutadorAtualizado);

	void deleteRecrutador(Long id);
}
