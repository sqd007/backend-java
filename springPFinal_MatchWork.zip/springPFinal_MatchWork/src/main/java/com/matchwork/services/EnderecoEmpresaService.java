package com.matchwork.services;

import java.util.List;

import com.matchwork.model.EnderecoEmpresa;

public interface EnderecoEmpresaService {
	
	List<EnderecoEmpresa> getAllEnderecosEmpresa();

	EnderecoEmpresa getEnderecoEmpresaById(Long id);

	EnderecoEmpresa saveEnderecoEmpresa(EnderecoEmpresa enderecoEmpresa);

	EnderecoEmpresa updateEnderecoEmpresa(Long id, EnderecoEmpresa enderecoEmpresaAtualizada);

	void deleteEnderecoEmpresa(Long id);
}

