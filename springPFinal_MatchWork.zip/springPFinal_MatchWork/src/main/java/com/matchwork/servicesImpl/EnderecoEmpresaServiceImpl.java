package com.matchwork.servicesImpl;

import java.util.List;

import org.springframework.transaction.annotation.Transactional;

import com.matchwork.model.EnderecoEmpresa;
import com.matchwork.repositories.EnderecoEmpresaRepository;
import com.matchwork.services.EnderecoEmpresaService;

public class EnderecoEmpresaServiceImpl implements EnderecoEmpresaService {

	EnderecoEmpresaRepository enderecoEmpresaRepository;

	@Override
	public List<EnderecoEmpresa> getAllEnderecosEmpresa() {
		return enderecoEmpresaRepository.findAll();
	}

	@Override
	@Transactional(readOnly = true)
	public EnderecoEmpresa getEnderecoEmpresaById(Long id) {
		return enderecoEmpresaRepository.findById(id).orElse(null);
	}

	@Override
	@Transactional
	public EnderecoEmpresa saveEnderecoEmpresa(EnderecoEmpresa enderecoEmpresa) {
		return enderecoEmpresaRepository.save(enderecoEmpresa);
	}

	@Override
	public EnderecoEmpresa updateEnderecoEmpresa(Long id, EnderecoEmpresa enderecoEmpresaAtualizada) {
		EnderecoEmpresa enderecoExistente = enderecoEmpresaRepository.findById(id).orElse(null);
		if (enderecoExistente != null) {
			enderecoExistente.setEndereco(enderecoEmpresaAtualizada.getEndereco());
			enderecoExistente.setBairro(enderecoEmpresaAtualizada.getBairro());
			enderecoExistente.setCidade(enderecoEmpresaAtualizada.getCidade());
			enderecoExistente.setEstado(enderecoEmpresaAtualizada.getEstado());
			enderecoExistente.setCep(enderecoEmpresaAtualizada.getCep());
			return enderecoEmpresaRepository.save(enderecoExistente);
		} else {
			throw new RuntimeException("Endereco de id: " + id + "nao encontrado!");
		}
	}

	@Override
	public void deleteEnderecoEmpresa(Long id) {
		enderecoEmpresaRepository.deleteById(id);

	}

}
