package com.matchwork.servicesImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.matchwork.model.Candidato;
import com.matchwork.repositories.CandidatoRepository;
import com.matchwork.services.CandidatoService;



@Service
public class CandidatoServiceImpl implements CandidatoService {

	@Autowired
	private CandidatoRepository candidatoRepository;
	
	@Override
	public List<Candidato> getAllCandidatos() {
		return candidatoRepository.findAll();
	}

	@Override
	@Transactional(readOnly = true)
	public Candidato getCandidatoById(Long id) {
		return candidatoRepository.findById(id).orElse(null);
	}

	@Override
	@Transactional
	public Candidato saveCandidato(Candidato candidato) {
		return candidatoRepository.save(candidato);
	}

	@Override
	public Candidato updateCandidato(Long id, Candidato candidatoAtualizado) {
		Candidato candidatoExistente = candidatoRepository.findById(id).orElse(null);
		if (candidatoExistente != null) {
			candidatoExistente.setNome(candidatoAtualizado.getNome());
			candidatoExistente.setSobrenome(candidatoAtualizado.getSobrenome());
			candidatoExistente.setDatanascimento(candidatoAtualizado.getDatanascimento());
			candidatoExistente.setCpf(candidatoAtualizado.getCpf());
			candidatoExistente.setGenero(candidatoAtualizado.getGenero());
			candidatoExistente.setFotoUrl(candidatoAtualizado.getFotoUrl());
			candidatoExistente.setEmail(candidatoAtualizado.getEmail());
			candidatoExistente.setSenha(candidatoAtualizado.getSenha());
			candidatoExistente.setTelefone(candidatoAtualizado.getTelefone());
			return candidatoRepository.save(candidatoExistente);
			
		} else {
			throw new RuntimeException ("Candidato com o id:" + id + "nao encontrado!"); 
		}
	}

	@Override
	public void deleteCandidato(Long id) {
		candidatoRepository.deleteById(id);
	}

}
