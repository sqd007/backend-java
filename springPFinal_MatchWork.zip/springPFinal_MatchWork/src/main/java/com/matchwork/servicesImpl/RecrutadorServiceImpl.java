package com.matchwork.servicesImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.matchwork.model.Recrutador;
import com.matchwork.repositories.RecrutadorRepository;
import com.matchwork.services.RecrutadorService;

@Service
public class RecrutadorServiceImpl implements RecrutadorService {

	@Autowired
	RecrutadorRepository recrutadorRepository;
	
	
	@Override
	public List<Recrutador> getAllRecrutadores() {
		return recrutadorRepository.findAll();
	}

	@Override
	@Transactional(readOnly = true)
	public Recrutador getRecrutadorById(Long id) {
		return recrutadorRepository.findById(id).orElse(null);
	}

	@Override
	public Recrutador saveRecrutador(Recrutador recrutador) {
		return recrutadorRepository.save(recrutador);
	}

	@Override
	public Recrutador updateRecrutador(Long id, Recrutador recrutadorAtualizado) {
		Recrutador recrutadorExistente = recrutadorRepository.findById(id).orElse(recrutadorAtualizado);
		if (recrutadorExistente != null) {
			recrutadorExistente.setNome(recrutadorAtualizado.getNome());
			recrutadorExistente.setSobrenome(recrutadorAtualizado.getSobrenome());
			recrutadorExistente.setDatanascimento(recrutadorAtualizado.getDatanascimento());
			recrutadorExistente.setCpf(recrutadorAtualizado.getCpf());
			recrutadorExistente.setCargo(recrutadorAtualizado.getCargo());
			recrutadorExistente.setEmail(recrutadorAtualizado.getEmail());
			recrutadorExistente.setSenha(recrutadorAtualizado.getSenha());
			recrutadorExistente.setTelefone(recrutadorAtualizado.getTelefone());
			return recrutadorRepository.save(recrutadorExistente);
		}	else {
			throw new RuntimeException ("Recrutador com o id: " + id + "nao encontrado.");
		}
	}

	@Override
	public void deleteRecrutador(Long id) {
		recrutadorRepository.deleteById(id);
		
	}

}
