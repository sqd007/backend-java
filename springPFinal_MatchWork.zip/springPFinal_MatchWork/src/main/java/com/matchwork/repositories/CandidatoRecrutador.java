package com.matchwork.repositories;

public interface CandidatoRecrutador {
	
	String getEmail();
	String getSenha();
	String getTipo();
	
}
