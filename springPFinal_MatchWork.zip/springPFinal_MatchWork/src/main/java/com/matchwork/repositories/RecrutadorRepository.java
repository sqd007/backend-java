package com.matchwork.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.matchwork.model.Recrutador;

@Repository
public interface RecrutadorRepository extends JpaRepository<Recrutador, Long>{

}
