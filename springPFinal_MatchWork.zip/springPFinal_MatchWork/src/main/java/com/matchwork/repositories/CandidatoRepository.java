package com.matchwork.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.matchwork.model.Candidato;

@Repository
public interface CandidatoRepository extends JpaRepository<Candidato, Long> {
	
	@Query(value = "SELECT email, senha, 'candidato' as tipo FROM Candidato c " +
            "WHERE c.email = :email AND c.senha = :senha " +
            "UNION " +
            "SELECT email, senha, 'recrutador' as tipo FROM Recrutador r " +
            "WHERE r.email = :email AND r.senha = :senha " +
            "UNION " +
            "SELECT 'admin@matchwork.com' as email, 'admin123' as senha, 'admin' as tipo " +
            "FROM Recrutador a " +
            "WHERE a.email = :email AND a.senha = :senha", nativeQuery = false)
	CandidatoRecrutador findByEmailAndSenha(@Param("email") String email, @Param("senha") String senha);	
		
}
