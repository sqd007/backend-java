package com.matchwork.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.matchwork.repositories.CandidatoRecrutador;
import com.matchwork.repositories.CandidatoRepository;

@Controller
@RequestMapping("/login")
public class LoginController {
	
	@Autowired
	private CandidatoRepository candidatoRepository;
	

	@GetMapping
	public String login(Model model) {
		model.addAttribute("dados", new Dados());
		return "login";
	}
	
	@PostMapping
	public String login(@ModelAttribute Dados dados){
		
		String email = dados.getEmail();
		String senha = dados.getSenha();
		
		if (email.equals("admin@matchwork.com")) {
			return "redirect:/candidatos";
		} 
		
		
		CandidatoRecrutador candidatoRecrutador = candidatoRepository.findByEmailAndSenha(email, senha);
		if (candidatoRecrutador.getTipo().equals("candidato")) {
		return "redirect:/dashboard_candidato";	
		} else if (candidatoRecrutador.getTipo().equals("recrutador")) {
			return "redirect:/dashboard_recrutador";
		} 
		
		return "login";
		
	}
}