package com.matchwork.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.matchwork.model.Candidato;
import com.matchwork.services.CandidatoService;

@Controller
@RequestMapping("/candidatos")
public class CandidatoController {

	@Autowired
	private CandidatoService candidatoService;
	
	@GetMapping
	public String listCandidatos(Model model) {
		List<Candidato> candidatos = candidatoService.getAllCandidatos();
		model.addAttribute("candidatos", candidatos);
		return "ListarCandidatos";
	}
	
	//Formulario Criacao candidato
	@GetMapping("/novo")
	public String showFormForAdd(Model model) {
		Candidato candidato = new Candidato();
		model.addAttribute("candidato",candidato);
		return "CandidatoForm";
	}
	
	//Persistencia Criacao
	@PostMapping("/save")
	public String saveCandidato(@ModelAttribute("candidato") Candidato candidato) {
		candidatoService.saveCandidato(candidato);
		return "redirect:/candidatos";
	}
	
	//Formulario edicao candidato
	@GetMapping("/editar/{id}")
	public String showFormForUpdate(@PathVariable Long id, Model model) {
		Candidato candidato = candidatoService.getCandidatoById(id);
		model.addAttribute("candidato",candidato);
		return "editarCandidato";
	}
	
	//Persistencia da Edicao
	@PostMapping("/editar/{id}")
	public String updateCandidato(@PathVariable Long id, @ModelAttribute("candidato") Candidato candidato) {
		candidatoService.updateCandidato(id, candidato);
		return "redirect:/candidatos";
	}
	
	//Excluir categoria
	@GetMapping("/deletar/{id}")
	public String deleteCandidato(@PathVariable Long id) {
		candidatoService.deleteCandidato(id);
		return "redirect:/candidatos";
	}
}
