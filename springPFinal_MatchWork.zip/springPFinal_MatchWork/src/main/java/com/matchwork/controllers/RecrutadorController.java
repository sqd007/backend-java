package com.matchwork.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.matchwork.model.Recrutador;
import com.matchwork.services.RecrutadorService;

@Controller
@RequestMapping("/recrutadores")
public class RecrutadorController {

	@Autowired
	private RecrutadorService recrutadorService;
	
	@GetMapping
	public String listRecrutadores(Model model) {
		List<Recrutador> recrutadores = recrutadorService.getAllRecrutadores();
		model.addAttribute("recrutadores", recrutadores);
		return "ListarRecrutadores";
	}
	
	//Formulario Criacao candidato
	@GetMapping("/novo")
	public String showFormForAdd(Model model) {
		Recrutador recrutador = new Recrutador();
		model.addAttribute("recrutador",recrutador);
		return "RecrutadorForm";
	}
	
	//Persistencia Criacao
	@PostMapping("/save")
	public String saveRecrutador(@ModelAttribute("recrutador") Recrutador recrutador) {
		recrutadorService.saveRecrutador(recrutador);
		return "redirect:/recrutadores";
	}
	
	//Formulario edicao candidato
	@GetMapping("/editar/{id}")
	public String showFormForUpdate(@PathVariable Long id, Model model) {
		Recrutador recrutador = recrutadorService.getRecrutadorById(id);
		model.addAttribute("recrutador",recrutador);
		return "editarRecrutador";
	}
	
	//Persistencia da Edicao
	@PostMapping("/editar/{id}")
	public String updateRecrutador(@PathVariable Long id, @ModelAttribute("recrutador") Recrutador recrutador) {
		recrutadorService.updateRecrutador(id, recrutador);
		return "redirect:/recrutadores";
	}
	
	//Excluir categoria
	@GetMapping("/deletar/{id}")
	public String deleteRecrutador(@PathVariable Long id) {
		recrutadorService.deleteRecrutador(id);
		return "redirect:/recrutadores";
	}
}
