package com.matchwork.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class DashboardController {

	@GetMapping("/dashboard_candidato")
	public String index() {
		return "dashboard_candidato";
	}

	@GetMapping("/match")
	public String match() {
		return "match";
	}

	@GetMapping("/dicas")
	public String dicas() {
		return "dicas";
	}

	@GetMapping("/cursos")
	public String cursos() {
		return "cursos";
	}
	
	@GetMapping("/contato")
	public String contato() {
		return "contato";
	}
	
	@GetMapping("/sobre")
	public String sobre() {
		return "sobre";
	}
}
